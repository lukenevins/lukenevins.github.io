# Claude Code Prompt: Luke Nevins Personal Website (v3)

## Critical Rule

**DO NOT invent, fabricate, or add ANY content.** All text, names, titles, lists, and descriptions must come ONLY from `content-manifest.md` in this project directory. Read that file FIRST before writing any HTML.

---

## Overview

Build a single-page personal website for Luke Nevins. Diary/digital garden feel, not a portfolio. Warm, fun, personal.

Inspired by https://chester.how/ layout. **Tech stack:** Plain HTML, CSS, vanilla JS. Three files: `index.html`, `styles.css`, `script.js`.

---

## Typography

Use **Nunito** from Google Fonts — rounded, friendly, personality-forward. NOT a corporate sans-serif.

```
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap');
```

- Name: 800 weight, 3rem
- Tagline: 500 weight, 1.1rem, letterspaced
- Bio: 500 weight, **1.25rem**, line-height 1.7 — **big and easy to read, only 4 short sentences**
- Card category labels: 700 weight, 0.7rem, uppercase, letterspaced
- Card body text: 400-500 weight, 0.95rem

---

## Color Palette

Two-tone layout: **dark navy left column, warm cream right column.**

### Left Column (Bio)
- **Background:** Deep navy `#0f1a2e`
- **Text — name/headings:** Warm cream `#f5efe6`
- **Text — body:** Soft cream `#d4c8b8`
- **Text — muted:** Blue-gray `#8a9bbd`
- **Social link pills:** Border of `#2c4a82`, text `#d4b896`, hover fill `#243b6e`
- **Sticky note card:** Cream `#f5efe6` background with navy `#0f1a2e` text

### Right Column (Cards)
- **Background:** Warm cream `#f5efe6`
- **Card backgrounds:** White `#ffffff` with subtle shadow
- **Card border on hover:** `#5b8def` glow
- **Text — headings:** Deep navy `#0f1a2e`
- **Text — body:** Dark navy `#1a2744`
- **Text — muted/labels:** `#6b7a94`
- **Accent pills/tags:** Navy `#1a2744` background with cream text, or outlined with navy border
- **Highlight cards** ("Things That Make Me Happy," "Favorite Color"): Light blue tint `#e8f0fe` or soft navy `#1a2744` with cream text — your choice, just make them stand out

---

## Layout

Single scrolling page. Two zones:

### Left Column — Bio (Desktop: sticky, ~35% width)
**Position: sticky**, stays visible while user scrolls cards on the right. Full-height viewport on desktop. On mobile, becomes a full-width section that scrolls normally.

Contains (in order):
1. Initials circle (navy with cream "LN")
2. Name: "Luke Nevins" — **big, 3rem, bold**
3. Tagline
4. Bio paragraph — **SHORT (4 sentences), BIG font (1.25rem)**. Read from manifest.
5. Social links row (pill-style buttons)
6. Cream sticky note: "For my professional side, head to my LinkedIn"

### Right Column — Cards (~65% width desktop, 100% mobile)
**Background: warm cream `#f5efe6`**

**First element: Cycling Hero Tile** (full width of right column)

**Then: Dense bento grid** of diary cards. Cards should pack tightly with 10-12px gaps. Use CSS Grid with varied column/row spans. No dead space.

---

## Cycling Hero Tile — "Currently working on..."

Largest card. Spans full width of right column. White card on the cream background.

**Behavior — RAPID FIRE:**
1. Static heading: "Currently working on..."
2. Below it, items cycle with a **fast typewriter effect:**
   - Type speed: **25ms per character** (fast)
   - Hold time: **0.4 seconds** (barely a pause)
   - Erase speed: **15ms per character** (even faster erasing)
   - This should feel like a rapid-fire montage, almost too fast to fully read
3. After ALL items, types the outro: "...but that's boring. Scroll down for the good stuff ↓"
4. Outro types at normal speed (50ms) and stays permanently
5. Blinking cursor `|` during typing

**Styling:** White card background, navy text. Heading in muted blue-gray. Cycling text in bold navy, 1.3rem. Outro text in the cream/tan accent `#d4b896`.

---

## Content Cards (18 cards)

Read ALL content from `content-manifest.md`. Cards:

1. **Coffee Order** — small card, punchy
2. **On Repeat** — playlist rows, artist names with small colored dot accents
3. **Currently Watching** — two shows with italic notes
4. **All-Time Favorites** — type labels (Movie, TV Show, Food, etc.) with values
5. **Movement Menu** — activity name pills/tags; hover reveals detail text
6. **Currently Reading** — book display card with placeholder image, title, author, note
7. **Book Recs** — list with **title and author** for each book
8. **Podcasts** — featured ritual podcast, then smaller list of others
9. **Grocery List** — interactive checklist (strikethrough + opacity on click)
10. **On the Menu** — meal names with notes
11. **Favorite Slop Bowl** — small card, one-liner
12. **Favorite Places** — list with small location pin icons
13. **Watchlist** — queued titles with footer note
14. **On the Horizon** — upcoming plans/events
15. **Favorite Color** — grid of 12 blue color swatches (solid squares), caption below: "Could you guess?"
16. **With People I Love** — large card, placeholder image, caption
17. **Walks & Hikes** — placeholder image, caption
18. **Things That Make Me Happy** — highlight card (light blue or navy background), freeform tags

### Card Design Rules
- **Background:** White `#ffffff` on the cream page
- **Rounded corners:** 14px
- **Shadow:** `0 1px 4px rgba(15,26,46,0.06), 0 4px 16px rgba(15,26,46,0.04)`
- **Gaps:** 10-12px between cards. Dense, packed layout.
- **Vary sizes:** Some 1-col, some 2-col span. Some short, some tall. Organic rhythm.
- **Category labels:** Top of card, uppercase, letterspaced, muted `#6b7a94`, 0.7rem
- **Hover:** Border glow `box-shadow: 0 0 0 2px #5b8def`, translateY(-2px), 0.2s ease
- **No large empty space** around or between cards

### Card Interactions
- **Grocery List:** Checkboxes, strikethrough + fade on click
- **Movement Menu:** Pill tags, hover shows detail
- **Favorite Color:** Grid of 12 solid-color squares in various blues

---

## Animations

- **Scroll fade-in:** Cards slide up 20px + fade via IntersectionObserver. Stagger 60ms.
- **Typewriter** on hero tile (rapid, specs above)
- `html { scroll-behavior: smooth; }`
- No libraries.

---

## Responsive

- **Desktop (>1024px):** Two columns. Left sticky. Right bento grid 2-3 card columns.
- **Tablet (768-1024px):** Left column full-width header. Cards 2-column grid.
- **Mobile (<768px):** Single column stacked.

---

## Image Placeholders

Soft gray rectangles (`#e2e0dc`) with centered muted text. HTML comment `<!-- REPLACE: description -->` above each.

---

## File Structure

```
/
├── index.html
├── styles.css
├── script.js
├── content-manifest.md
└── /images/
    └── README.md ("Add your images here")
```

---

## Footer

Muted text, centered: "Built by Luke, powered by Claude Code & too much coffee."

---

## Key Changes from v2

1. **Cream background on right pane** (not navy everywhere)
2. **Nunito font** — rounded and fun, not corporate
3. **Shorter bio, bigger font** (4 sentences at 1.25rem)
4. **Rapid-fire cycling tile** (25ms type, 0.4s hold, 15ms erase)
5. **Favorite Color card** with blue swatch grid
6. **Book recs include authors**
7. **All content cleaned** — proper capitalization, grammar, spelling
