# CONTENT MANIFEST — Luke Nevins Personal Website
# Claude Code: DO NOT invent, fabricate, or add ANY content not in this file.
# If a field says "placeholder," use a placeholder box with the label noted.

---

## BIO SECTION (Left Column)

name: "Luke Nevins"
tagline: "student. builder. runner. over-caffeinated."

bio: >
  I'm Luke — a student at the University of Florida heading into consulting.
  On campus, I lead a team in REM and run pledge education for AKPsi.
  I build things that matter and tinker in Claude Code at 2am.
  This is my corner of the internet. Welcome.

social_links:
  - label: "LinkedIn"
    url: "#"
  - label: "Instagram"
    url: "#"
  - label: "GitHub"
    url: "#"
  - label: "Say Hi"
    url: "#"

professional_note: "For my professional side, head to my LinkedIn"

---

## CYCLING HERO TILE — "Currently working on..."

# Cycles through items RAPIDLY (typewriter at ~40ms per character, hold ~0.6s,
# then erase and move on). Should feel like a rapid-fire montage.
# After all items, lands on the outro and stays.

cycling_items:
  - "an AI automated email grader"
  - "a paper on the sanity condition of free will"
  - "a paper on whether ChatGPT is intelligent"
  - "reading philosophy excerpts"
  - "building events for my composting client"
  - "leading my team in REM"
  - "a random side project"
  - "BFI homework"
  - "a speech about problem gambling"
  - "grading resumes"
  - "building a slide deck"
  - "researching B Corps"
  - "taking notes"
  - "mentoring pledges"
  - "helping out a friend"
  - "switching to Claude"
  - "another random side project"
  - "building an AI nutrition model"
  - "creating this website"

cycling_outro: "...but that's boring. Scroll down for the good stuff ↓"

---

## CONTENT CARDS

### Card: Coffee Order
category_label: "Coffee Order"
content:
  - "Wawa Cuban Roast with a little cinnamon, or just the coffee my dad gives me."
  - "At least 2 cups a day."
image: placeholder ("coffee photo")

### Card: On Repeat
category_label: "On Repeat"
artists:
  - Harry Styles
  - Olivia Dean
  - Noah Kahan
  - Renee Rapp
  - Lizzy McAlpine
  - Lorde
  - Declan McKenna
  - Lana Del Rey
  - Olivia Rodrigo
  - Zach Bryan
  - Baby Keem
  - Kendrick Lamar

### Card: Currently Watching
category_label: "Currently Watching"
items:
  - title: "3 Body Problem"
    note: "Sci-fi that makes my brain hurt (in a good way)"
  - title: "Paradise"
    note: "Just started, no spoilers please"

### Card: All-Time Favorites
category_label: "All-Time Favorites"
items:
  - type: "Movie"
    value: "Dead Poets Society"
  - type: "TV Show"
    value: "The Day of the Jackal"
  - type: "Food"
    value: "Sugar Snap Peas"
  - type: "Dish"
    value: "Smoked Salmon Bagel"
  - type: "Place"
    value: "Valley Forge National Park"
  - type: "Book"
    value: "Ultra-Processed People"

### Card: Movement Menu
category_label: "Movement Menu"
activities:
  - name: "Running"
    detail: "5Ks and 10Ks, loving a good Zone 2 run"
  - name: "Lifting"
    detail: "Chest, back, arms, and legs (sometimes)"
  - name: "Yoga"
    detail: "Class or just doing downward dog randomly"
  - name: "Soccer"
    detail: "Whenever I can get a ball at my feet"
  - name: "Hiking"
    detail: "When it's nice out"
  - name: "Cycling"
    detail: "Getting into these classes"

### Card: Currently Reading
category_label: "Currently Reading"
book:
  title: "Ultra-Processed People"
  author: "Chris van Tulleken"
  note: "This one changed how I look at food labels forever."
image: placeholder ("book cover")

### Card: Book Recs
category_label: "Book Recs"
books:
  - title: "The Vegetarian"
    author: "Han Kang"
  - title: "The Sense of an Ending"
    author: "Julian Barnes"
  - title: "Terrible Humans"
    author: "Simon Makin"
  - title: "Food for Life"
    author: "Tim Spector"
  - title: "The Alternative"
    author: "Nick Romeo"
  - title: "Extreme Ownership"
    author: "Jocko Willink & Leif Babin"

### Card: Podcasts
category_label: "Podcasts"
ritual: "Morning Brew Daily"
ritual_note: "How I pretend to be informed before 9am"
also_listening:
  - "Pod Save America"
  - "Within Reason — Alex O'Connor"
  - "How Is This Better? — COURIER"
  - "Get Down to Business: The B Corp Podcast"
  - "Beyond the B — LIFT Economy"
  - "Binchtopia"

### Card: Grocery List
category_label: "This Week's Grocery List"
items:
  - "Vanilla Almond MALK"
  - "Whole Foods Heritage Grain Sourdough"
  - "Sugar Snap Peas (obviously)"
  - "PBfit Powder"
  - "Tofu"
  - "Protein Pasta"
  - "Everything But the Bagel Seasoning"
  - "Sriracha"
  - "Dry Roasted Edamame & Chickpeas"
  - "Carrot Sticks"
  - "Broccoli"
footer_note: "High-protein, high-fiber, pesketarian life"

### Card: On the Menu
category_label: "On the Menu"
meals:
  - name: "My pasta with tofu, marinara, and parmesan sauce"
    note: "It's good, trust"
  - name: "Salmon salad bowl"
  - name: "Rice cakes with Greek yogurt and pomegranate"
  - name: "High-protein overnight oats"

### Card: Favorite Slop Bowl
category_label: "Favorite Slop Bowl"
content: "CAVA chicken + sweet potato with harissa and red pepper hummus."

### Card: Favorite Places
category_label: "Favorite Places"
places:
  - "Valley Forge National Park"
  - "Mad Anthony Wayne Cafe"
  - "Depot Park"
  - "Brewing Thoughts Coffee"
  - "Camden, Maine"
  - "Boston!"

### Card: Watchlist
category_label: "Watchlist"
items:
  - "Oppenheimer"
  - "Fight Club"
  - "Black Swan"
  - "Inception"
footer_note: "Will get to these... eventually"

### Card: On the Horizon
category_label: "On the Horizon"
items:
  - "March Madness (go Gators 🐊)"
  - "Moving to Boston for the summer!"
  - "Trip to New York"

### Card: Favorite Color
category_label: "Favorite Color"
# Display a grid of 9-12 squares in various shades of blue, from navy to sky
# to teal to royal to baby blue. Each square is a solid color swatch.
# Below the grid, caption: "Could you guess?"
blue_shades:
  - "#0a1628"
  - "#1a2744"
  - "#243b6e"
  - "#2c4a82"
  - "#3a6ea5"
  - "#5b8def"
  - "#7ba4f7"
  - "#89CFF0"
  - "#4169E1"
  - "#1E90FF"
  - "#6495ED"
  - "#B0E0E6"
caption: "Could you guess?"

### Card: With People I Love
category_label: "With People I Love"
caption: "The best part of all of this."
image: placeholder ("group photo")

### Card: Walks & Hikes
category_label: "Walks & Hikes"
caption: "Decompression therapy."
image: placeholder ("nature/trail photo")

### Card: Things That Make Me Happy
category_label: "Things That Make Me Happy"
items:
  - "Family dinners"
  - "Farmers markets"
  - "A good podcast on a long walk"
  - "When the code runs on the first try"
  - "Dark roast in a ceramic mug"
  - "Sugar snap peas straight from the bag"

---

## FOOTER

footer_text: "Built by Luke, powered by Claude Code & too much coffee."
